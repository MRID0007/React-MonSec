def SecurePasswordHasher1(password):
    hashed = ""
    for char in password:
        num = ord(char)
        num += 15
        hashed += str(num) + '.'
    return hashed