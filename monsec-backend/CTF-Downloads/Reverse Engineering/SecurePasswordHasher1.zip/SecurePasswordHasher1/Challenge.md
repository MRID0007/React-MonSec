# Secure Password Hasher 1
### 50 pts

## Challenge Description
I have created a new, secure [password hasher](ultimateHasher1.py)! This means that even if you have my password, I can hash it so you'll never be able to use it... Right?

My password: 92.94.93.98.84.82.138.93.63.99.110.101.66.97.104.110.98.66.82.100.97.66.140.

## Hints
1. Can you figure out what each line of code is doing? You might have to look it up!
2. ord() can turn a character into a number. 
3. You could do this without code, since it's effectively a weak substitution cipher.