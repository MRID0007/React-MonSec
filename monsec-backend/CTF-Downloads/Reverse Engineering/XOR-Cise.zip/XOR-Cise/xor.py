def xor(string, key):
    result = ""
    for i in range(len(string)):
        result += encrypt(string[i], key[i])
    return result

def encrypt(string, key):
  code = ord(string) ^ ord(key)
  character = chr(code)
  return character