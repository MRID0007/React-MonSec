# XOR-Cise
### 50 pts

## Challenge Description
Do you know how XOR works?

Code: [xor.py](xor.py)
Flag: 56!H0=(1
Key: mysecret

You'll need to wrap the decrypted message in the MONSEC{} wrapper.

## Hints
1. https://medium.com/@epipo555/simple-cipher-fe248201833f#:~:text=The%20reverse%20of%20any%20xor,you%20back%20where%20you%20started.