# Secure Password Hasher 2
### 100 pts

## Challenge Description
Okay, I think I've learnt from my mistakes now. This new and improved hasher should be uncrackable because it's totally random!

My password: RChGHXjl~eyHKQm{PldCKJqgw
New hash function: [ultimateHasher2.py](ultimateHasher2.py)

## Hints
1. Is it really random?
2. What does a seed do?
3. Look at the XOR-cise challenge if you're stuck reversing the ciphertext