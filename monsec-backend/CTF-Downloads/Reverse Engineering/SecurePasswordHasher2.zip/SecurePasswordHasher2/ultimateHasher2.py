import random

random.seed(2024)

def SecurePasswordHasher2(password):
    my_bytes = str.encode(password)
    encoded = ""
    for byte in my_bytes:
        secret = random.randint(1,42)
        ciphertext = chr((byte ^ secret))
        encoded += ciphertext
    return encoded