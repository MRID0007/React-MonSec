# My City
### 200 pts

## Challenge Description
Hmmmm, [this place](river.jpg) looks familiar but I can't quite remember where it is. Do you know?

The flag is the name of the city in all capitals (in which the photo is taken) wrapped in the MONSEC{} wrapper. For example, if the photo was taken in Berlin, it would be MONSEC{BERLIN}.

## Hints
1. What landmarks can you recognise?
2. Is any text visible?