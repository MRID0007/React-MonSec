# Vista Point
### 200 pts

## Challenge Description
What a [pretty vista](city_vista.jpg)! I wonder which city this photo was taken in?

The flag is the name of the city in all capitals wrapped in the MONSEC{} wrapper. For example, if the photo was taken in Berlin, it would be MONSEC{BERLIN}.

## Hints
1. What landmarks can you recognise?
2. What about the style of the buildings?