# Beach
### 100 pts

## Challenge Description
[This](beach.jpg) looks like a nice, sunny beach. Can you work out where it is?

The flag is the area postcode wrapped in the MONSEC{} wrapper. For example, if the postcode was 0011, the flag would be MONSEC{0011}.

## Hints
1. What text is visible in the image?