# Hometown
### 50 pts

## Challenge Description
I took [this photo](picture.jpg) while visiting my friend's hometown. Do you know where they live?

The flag is the name of the city in all capitals (in which the photo is taken) wrapped in the MONSEC{} wrapper. For example, if the photo was taken in Berlin, it would be MONSEC{BERLIN}.

## Hints
1. Do you recognise any of the buildings/landmarks?
2. Can you use any text found in the image?