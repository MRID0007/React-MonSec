# Crowded
### 100 pts

## Challenge Description
My friend sent me [this picture](crowded.jpg) a while ago. I think they were at some kind of event. Can you work out when the photo was taken?

The flag is the year the photo was taken, wrappd in the MONSEC{} wrapper. For example, if the image was taken in 2024, the flag would be MONSEC{2024}

## Hints
1. What text can you see?
2. What can you learn from what the crowd is wearing?
3. How's your F1 knowledge?