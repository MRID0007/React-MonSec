# Holiday Snaps
### 100 pts

## Challenge Description
I was looking through my photo album and found [this picture](holiday.jpg) that I took while on holiday. However, I can't remember where I took the photo. Can you find out where I took the photo?

The flag is the name of the city in all capitals wrapped in the MONSEC{} wrapper. For example, if the photo was taken in Berlin, it would be MONSEC{BERLIN}.

## Hints
1. Ever used reverse image search?
