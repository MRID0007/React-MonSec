# Sunrise
### 100 pts

## Challenge Description
What a [lovely sunrise](ocean.jpg). I wonder where the photo was taken?

The flag is the country in which the photo was taken, in all capitals, wrapped in the MONSEC{} wrapper. For example, if the photo was taken in Sweden, the flag would be MONSEC{SWEDEN}.

## Hints
1. How can you see where a photo was taken?
2. Where is geolocation data stored in an image?