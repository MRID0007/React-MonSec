# Dinner Recommendation
### 50 pts

## Challenge Description
A friend recommended [this place](dinner.jpg) for dinner but I can't remember the address- I only have this picture of the front door. Can you work out where it is?

The flag is the name of the street/road/court/etc in capital letters, wrapped with the MONSEC{} wrapper. For example, if the answer was Smith Boulevard, the answer would be MONSEC{SMITH} or if it was Lupton Street, it would be MONSEC{LUPTON}.

## Hints
1. What text is visible in the image?