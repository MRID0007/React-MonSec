# Nature
### 200 pts

## Challenge Description
It might not seem like much but this is a [famous landmark](landscape.jpg). Do you know what it is?

The flag is the native name of the landmark in all capitals (in which the photo is taken) wrapped in the MONSEC{} wrapper. For example, if the photo was of Ayres Rock, the 'native name' would be Uluru and the flag would be MONSEC{ULURU}

## Hints
1. You might have to do some research
2. Don't forget the hyphen