# Salad Cipher
### 50 pts

## Challenge Description
I was trying to make a secret message and ended up making a [letter salad](salad.txt)... Can you make any sense of it?

## Hints
1. What do salads, Romans and Shakespeare have in common?
