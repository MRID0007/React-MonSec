# Of-fence-ive Security
### 50 pts

## Challenge Description
I've made an unbreakable code! Now I can store all my [super secret messages](secret.txt) in this code...

Wrap the decoded message with MONSEC{} to get the flag.

## Hints
1. Have you heard of the rail fence cipher?