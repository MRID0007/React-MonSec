# Boring Website
### 50 pts

## Challenge Description
This website is so boring and definitely doesn't have any secrets!

## Hints
1. Is this the only page that exists?