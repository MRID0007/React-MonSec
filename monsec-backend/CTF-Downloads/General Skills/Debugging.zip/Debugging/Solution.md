# Debugging
### 50 pts

## Challenge Solution
The decrement value should be -1, not -2.

Completed code:
```py
jumbled = [125, 33, 103, 117, 98, 95, 51, 104, 116, 95, 100, 110, 117, 48, 102, 95, 117, 123, 67, 69, 83, 78, 79, 77]
flag = ""
for i in range(len(jumbled)-1, -1, -1):
    flag += chr(jumbled[i])
print(flag)
```

Flag: MONSEC{u_f0und_th3_bug!}