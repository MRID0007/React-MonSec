# Debugging
### 50 pts

## Challenge Description
I was trying to decode this flag but there's a bug in [my code](solution.py) and I can't seem to get the right answer... Can you fix it?

## Hints
1. What three arguments can range() take?
2. What happens if you change the numbers?
3. What happens if you change the third number?