# Sanity Check
### 5 pts

## Challenge Description
Download [this file](flag.txt) and find the flag.

## Hints
None