# Happily Ever After
### 100 pts

## Challenge Description
I found this [strange file](unusual.pdf) but I can't seem to open it. Maybe you can find a way to read it.

## Hints
1. Have you checked the header?
2. What type of file is it really?
3. This is harder to do on MacOS than it is on Windows, generally speaking.