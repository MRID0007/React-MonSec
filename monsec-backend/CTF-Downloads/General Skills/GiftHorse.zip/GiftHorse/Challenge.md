# Gift Horse
### 50 pts

## Challenge Description
What is the (shortform) name of the type of malware that can infiltrate systems by disguising itself as legitimate software?

Write it in capital letters and wrap it in the MONSEC{} wrapper to get the flag.

## Hints
None