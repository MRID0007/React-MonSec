# Mystery Cat
### 50 pts

## Challenge Description
This [cat](cat.jpg) is so cute that it can't be hiding a secret... Could it?

## Hints
1. I wonder who owns the cat?
2. Do you know what metadata is?