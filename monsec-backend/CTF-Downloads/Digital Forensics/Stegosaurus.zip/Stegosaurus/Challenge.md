# Stegosaurus
### 100 pts

## Challenge Description
This [stegosaurus](stegosaurus.jpg) is hiding a secret... Can you find it?

The password is the year MonSec was founded.

## Hints
1. You'll need a special tool to get the secret out
2. How do you hide files in images?
3. [Steghide](https://steghide.sourceforge.net/) is a really useful tool